package com.example.myapplication1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {

        lateinit var spinner: Spinner
        lateinit var textView: TextView
    lateinit var textview2: TextView

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)

            textView = findViewById(R.id.textview1)
            textview2 = findViewById(R.id.textview2)

            spinner = findViewById(R.id.mySpinner)
            val adapter = ArrayAdapter.createFromResource(
                this,
                R.array.softdrinks,
                android.R.layout.simple_spinner_item
            )
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter
            spinner.onItemSelectedListener=this

        }
        override fun onNothingSelected(parent: AdapterView<*>?) {
            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        }
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            val text: String = parent?.getItemAtPosition(position).toString()
            textView.text = "You have selected:" + text
            if (text=="Coke")
            {
                textview2.text ="This is a coco-cola product"
            }
            else  if (text=="Sprite")
            {
                textview2.text = "This is a sprite product"
            }
            else if (text=="Mazza")
            {
                textview2.text = "This is a mazza product"
            }
            else if (text=="Pepsi")
            {
                textview2.text = "This is a pepsi product"
            }
            else if (text=="Limca")
            {
                textview2.text = "This is a limca product"
            }

        }
    }